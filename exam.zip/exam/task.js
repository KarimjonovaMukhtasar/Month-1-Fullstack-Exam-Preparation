// Group Words by Anagrams
// Input: ["bat", "tab", "tap", "pat", "cat"]
// Output: [["bat", "tab"], ["tap", "pat"], ["cat"]]

//  Sort by Frequency
// Input: [4,1,2,1,2,3,3,3] → Output: [3,3,3,1,1,2,2,4]

// Rotate Array (k times)
// Input: [1,2,3,4,5,6,7], k = 3 → Output: [5,6,7,1,2,3,4]

// Check if Two Strings are Isomorphic
// egg = add  //true
// hello = salom //false

// Find Common Elements in Two Arrays
// Input: [1, 2, 3] and [2, 3, 4] → Output: [2, 3]

// Find Majority Element
// Input: [3, 3, 4, 2, 3, 3, 3] → Output: 3

// Remove K Digits to Get Smallest Number
// Input: num = "1432219", k = 3 → Output: "1219"

// Email checker
// Input: hello@loremipsum → Output: false
// Input: hello@lorem.ipsum → Output: true
// Input: he.llo@loremipsum. → Output: false
// Input: @hello.loremipsum → Output: false
// Input: @helloloremipsum → Output: false
// Input: hello.lor@emipsum → Output: false
// Input: hello@world.com → Output: true

// Function numberlardan iborat array qabul qiladi va juft indexdagi numberlarni array orqasiga qo'shib qaytaradi.
// Example:Function([1,2,3,4]) => [1,2,3,4, 1, 3]  1 va 3 qo'shilganining sababi ularning indexi juft yani 1 bu 0-indexda 3 esa 2-indexda
//
// Function array va string qabul qiladi. Qabul qilingan string array ichida qancha marotaba qaytarilganini sanaydi
// Example: function(["hello", "string hello", "woreld is beautiful"], "e") => "e" harfi arrayda 4 marta ishlatilgan.

// Function stringda so'z qabul qiladi, boshidagi va oxiridagi ikta harfni katta yozuvda chiqarib beradi. functionga 8 tadan kam so'z kiritib bo'lmasin!!!
// Example: function("javascript") => "JAvascriPT", function("java") => error:8 tadan kam harf kiritildi

// function 2 ta kun qabul qiladi (stringda NUMBER EMAS!) , shu ikta kun orasida nechchi soat bor ekanini qaytaradi.
// Example: function("25-october", "oktyabrning 27chisi") => "25-october" va "oktyabrning 27chisi" orasida 48 soat vaqt bor.  function ichiga qiymat hohlagan ko'rinishda string tarzda beriladi exampledagidek!!!
